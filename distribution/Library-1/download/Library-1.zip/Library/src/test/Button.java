package test;

import processing.core.*;

public class Button {
	
	PApplet app;

	float x, y, w, h;
	int sc, ac, pc;
	public boolean press;
	
	public final static String VERSION = "1.0.0";
	
	public Button(PApplet theParent) {
		app = theParent;
		welcome();
	}
	
	
	private void welcome() {
		System.out.println("Test Library 1.0.0 by Grigaror http://yoururl.com");
	}
	
	
	public void setGeometry(float x, float y, float w, float h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
	
	public void setColors(int s, int a, int p) {
		sc = s;
		ac = a;
		pc = p;
	}
	
	public void draw() {
		app.push();
		app.fill(sc);
		if (app.mouseX > x && app.mouseX < x+w && app.mouseY > y && app.mouseY < y+w) {
			app.fill(ac);
			if (app.mousePressed && app.mouseButton == 0) {
				press = true;
				app.fill(pc);
			}
			else press = false;
		}
		app.rect(w, y, w, h);
		app.pop();
	}
}

